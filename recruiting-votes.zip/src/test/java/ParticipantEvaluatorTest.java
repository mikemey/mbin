import com.opencsv.CSVReader;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ParticipantEvaluatorTest {

    private static final ParticipantEvaluator PARTICIPANT_EVALUATOR = new ParticipantEvaluator();
    private static List<Vote> TEST_DATA;

    @BeforeAll
    static void readTestData() throws Exception {
        final List<Vote> votes = new ArrayList<>();
        final CSVReader reader = new CSVReader(new FileReader("src/test/resources/votes.csv"));

        String[] line;
        while ((line = reader.readNext()) != null) {
            votes.add(new Vote(line));
        }

        TEST_DATA = votes;
    }

    @Test
    void checkParticipantNames() {
        final List<String> participantNames = PARTICIPANT_EVALUATOR.returnParticipants(TEST_DATA);
        System.out.println(participantNames);

        final List<String> upperCaseParticipantNames = participantNames.stream()
                .map(String::toUpperCase)
                .toList();
        assertThat(upperCaseParticipantNames)
                .containsExactlyInAnyOrder(
                        "JOHN",
                        "TANJA",
                        "BRAD",
                        "PATTY",
                        "HENRY",
                        "JIM",
                        "SHARON",
                        "EVELYN",
                        "ERWIN"
                );
    }

}
