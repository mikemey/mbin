import java.util.Collections;
import java.util.List;

public class ParticipantEvaluator {

    public List<String> returnParticipants(final List<Vote> votes) {
        // TODO implement me!
        return Collections.emptyList();
    }

}
