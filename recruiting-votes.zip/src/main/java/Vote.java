import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Vote {

    private Date timestamp;
    private String name;
    private boolean participate;

    private static final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    public Vote(String[] fields) {
        try {
            this.timestamp = format.parse(fields[0]);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        this.name = fields[1];
        this.participate = Boolean.parseBoolean(fields[2]);
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isParticipate() {
        return participate;
    }

    public void setParticipate(boolean participate) {
        this.participate = participate;
    }

    @Override
    public String toString() {
        return "Vote{" +
                "timestamp=" + timestamp +
                ", name='" + name + '\'' +
                ", participate=" + participate +
                '}';
    }
}
